import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

declare var jQuery: any;

@Component({
  selector: 'app-quote',
  templateUrl: './quote.component.html',
  styleUrls: ['./quote.component.css']
})
export class QuoteComponent implements OnInit {
  productName : string = '';
  dobText : string = '';
  gender : string = 'male';
  planTerm : string = '10 Years';
  ppType : string = '';
  sppTerm : string ='5 Years';
  pFrequency : string = '';
  sumAssured : any = '1000';
  premium : string = '';
  sumAssuredSlider : string = '5';

  constructor() { }

  ngOnInit() {
    jQuery('.datepicker').datepicker({
      buttonImage: "assets/images/datepicker.png"
    });
    jQuery('#sumAssuredSlider').slider({
      min: 0,
	    max: 400,
	    value: 5,
      tooltip_position:'bottom',
      ticks: [0, 100, 200, 300, 400],
      ticks_positions: [0, 30, 70, 90, 100],
      ticks_labels: ['0', '100', '200', '300', '400']
    }).on('change',this.sumAssuredSliderVal);
  }
  ppTypeChange(){
    $('.pTerm').hide()
    if(this.ppType == 'limited'){
      $('#limitedsppTerm').fadeIn();
    }else{
      $('#sppTerm').fadeIn();
    }
  };
  sumAssuredSliderVal(obj){
    //console.log(obj);
    setTimeout(function(){
      this.sumAssured = obj.value.newValue;
      console.log("summ--"+this.sumAssured);
    },10);
    
  };
  calculateQuote(){
    this.sumAssured = 20000;
  }
}
