import { Component , OnInit} from '@angular/core';
import * as $ from 'jquery';

declare var jQuery: any

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  //$ : any;
  title = 'POSP-Journey';
  ngOnInit(){
    //jQuery('.datepicker').datepicker();
  }
}
